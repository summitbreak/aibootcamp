"""
This module defines the version.
"""

__version__ = "1.0.4"
